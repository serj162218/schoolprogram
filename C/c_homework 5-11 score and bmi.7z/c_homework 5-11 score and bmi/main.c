#include <stdio.h>
#include <string.h>
int main(){
	FILE *file=NULL;
	file = fopen(".\\data\\data.txt","r");
	char str[3][250];
	char idmax[99],idmin[99];
	float num[2];
	float max = -999;
	float min = 999;
	if(file!=NULL){
		while(fscanf(file,"%s %s %s %f %f",str[0],str[1],str[2],&num[0],&num[1])!=EOF){
			if(num[0]>=18.5&&num[0]<=24){
				printf("%s %s\n",str[1],str[2]);
			}
			if(max<num[1]){
				max = num[1];
				stpcpy(idmax,str[1]);
				
			}
			else if(min>num[1]){
				min = num[1];
				stpcpy(idmin,str[1]);
			}
		
		}
		puts("Max:");
		printf("%s %.0f\n",idmax,max);
		puts("Min:");
		printf("%s %.0f",idmin,min);
	}
	fclose(file);
}
